public class ExercicioTres
{
    Curso curso;
    public ExercicioTres()
    {
        curso = new Curso();
    }
}
